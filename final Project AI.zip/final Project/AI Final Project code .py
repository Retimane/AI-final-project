#!/usr/bin/env python
# coding: utf-8

# In[11]:


import pandas as pd
from sklearn.tree import DecisionTreeClassifier, export_text
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn import tree
import matplotlib.pyplot as plt

# Load the data
file_path = 'FIFA 2018 Statistics.csv'  # Update this to your actual file path
fifa_stats = pd.read_csv(file_path)

# Selecting features and target
features = ['Goal Scored', 'Ball Possession %', 'Attempts', 'On-Target', 'Off-Target',
            'Blocked', 'Corners', 'Offsides', 'Free Kicks', 'Saves', 'Pass Accuracy %',
            'Passes', 'Distance Covered (Kms)', 'Fouls Committed', 'Yellow Card',
            'Yellow & Red', 'Red', '1st Goal']
target = 'Man of the Match'

# Dropping rows with missing values
fifa_stats_cleaned = fifa_stats.dropna(subset=features + [target])

# Encoding the target variable
label_encoder = LabelEncoder()
fifa_stats_cleaned[target] = label_encoder.fit_transform(fifa_stats_cleaned[target])

# Splitting the data into training and testing sets
X = fifa_stats_cleaned[features]
y = fifa_stats_cleaned[target]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Training the decision tree classifier
clf = DecisionTreeClassifier(random_state=42)
clf.fit(X_train, y_train)

# Visualizing the decision tree
plt.figure(figsize=(20, 10))
tree.plot_tree(clf, feature_names=features, class_names=label_encoder.classes_, filled=True)
plt.show()

# Printing the decision tree rules
tree_rules = export_text(clf, feature_names=features)
print(tree_rules)


# In[ ]:




